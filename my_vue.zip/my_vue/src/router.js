import Vue from 'vue'
import Router from 'vue-router'
import Index from './views/Index'
import Details from './views/Details'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      component: Index
    },
    {
      // 后面接参数lid
      path: '/details/:lid',
      component: Details,
      props:true, //将参数自动交给同名的props属性
    },
    
  ]
})
