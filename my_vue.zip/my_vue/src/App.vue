<template>
  <div id="app">
    <my-header></my-header>
    <router-view/>
  </div>
</template>

<style>

</style>
