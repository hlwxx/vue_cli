import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import MyHeader from './components/MyHeader'

// 将对象变为全局组件
Vue.component('my-header',MyHeader);

//用import语法引入axios模块(node_modules里的不需加路径)
import axios from 'axios'

//将axios对象强行添加到Vue的原型对象中(强行赋值): 
Vue.prototype.axios=axios;


Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
