//1 先拿到服务器端数据库的数据:
//1-1 在routes文件夹下新建并编辑首页路由器模块(类似于招服务员)
//引入express模块
const express=require('express');
//使用express创建路由器对象
const router=express.Router();
//引入连接池模块(可省pool后面的.js)
const pool=require('../pool.js');

//1-4 使用首页路由(服务员怎么接待)
//领班app.js分配的地址是：'/index' 路由器名
//自己分的地址是:       '/' 路由名
//最终的完整地址是(后面的斜线/加不加都行)：'/index/'
router.get('/',(req,res)=>{
  var sql=`SELECT * FROM xz_index_product WHERE seq_recommended!=0 ORDER BY seq_recommended`;
  //[]里面放占位符 动态接收数据
  pool.query(sql,[],(err,result)=>{

    if(err){
      //console.log(err);
      res.send({code:0});
    }else{
      res.send(result);
    }
  })
})

//1-5 路由写好后测试：
//打开mysql 在浏览器中输入 http://localhost:3000/index 要能得到从数据库拿到的相关数据

//导出路由器对象(服务员的统一着装)
module.exports=router;