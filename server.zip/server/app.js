//使用express构建web服务器
const express = require('express');
const bodyParser = require('body-parser');

//引入cors
const cors = require('cors');

/*1-2 引入路由模块(自定义模块 同一路径要加./) (类似于将服务员index.js介绍给领班app.js)*/
const index=require('./routes/index')

//引入details文件
const details = require('./routes/details');

//创建web服务器(app是变量名)
var app = express();

var server = app.listen(3000);

//node.js项目中所有的请求都要先过app.js 然后再由app.js分发给其他地方 在app.js中用中间件的方式提前改好res.writeHead 后面所有接口都不用单独改了
//位置：在创建服务器后解决跨域问题 
//下载模块 npm i -save cors  把cors文件夹放到node_modules里
//只写一次就可让整个服务端中所有接口都支持跨域
app.use(cors({
  // origin:'http://127.0.0.1:5500'
  origin:'*'
}))

//使用body-parser中间件
app.use(bodyParser.urlencoded({extended:false}));
//托管静态资源到public目录下
app.use(express.static('public'));

/*1-3 使用路由器来管理路由
使用路由器(参数为挂载的url为/index及引入时的路由器名)
app是web服务器变量名
(凡是找/index这个请求 都是index这个服务员接待)
*/
app.use('/index',index);

//使用details
app.use('/details',details);

